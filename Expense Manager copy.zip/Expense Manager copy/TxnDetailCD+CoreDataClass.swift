//
//  TxnDetailCD+CoreDataClass.swift
//  Expense Manager
//
//  Created by aashna.narula on 07/11/21.
//
//

import Foundation
import CoreData

@objc(TxnDetailCD)
public class TxnDetailCD: NSManagedObject {

}
